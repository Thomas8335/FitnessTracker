package cis2087finalproject;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;


import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;

public class FXMLDocumentController_1 implements Initializable
{
    private static Users users = new Users();
    
    
    private Stage stage;
    private Scene scene;
    private Parent root;

    // Controls from FXML GUI Interface.
    //Variables for login screen
    @FXML
    private Button button;

    
    //Variables for menu screen
    @FXML
    private ListView listViewDays;
    public static ObservableList<Day> dayList = FXCollections.observableArrayList(Day.extractor);
    private ChangeListener<Day> dayChangeListener;
    public static Day selectedDay;
    @FXML
    private Button viewLogsButton;
    @FXML
    private Button editDayButton;
    @FXML
    private Button addDayButton;
    @FXML
    private Label selectedDayLabel;
    @FXML
    private Button deleteDayButton;
    @FXML
    private RadioButton yes;
    @FXML
    private RadioButton no;
    @FXML
    private TextField textFieldCalories;
    @FXML
    private TextField textFieldProtein;
    //@FXML
    //private Text adviceText;
    //Variables for user
    @FXML
    private TextField newUserName;
    @FXML
    private TextField newPassword;
    @FXML
    private TextField age;
    @FXML
    private TextField height1;
    @FXML
    private TextField height2;
    @FXML
    private TextField weight;
    @FXML
    private TextField calorieGoal;
    @FXML
    private TextField proteinGoal;
    @FXML
    private RadioButton male;
    @FXML
    private RadioButton female;
    private User user;
    
   
    public static int key;
    
    
    
    
    
    
    
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        
    }
    
    //Check Logs button behavior
    public void checkLogs(ActionEvent event){
        
        
        Days days = new Days(key);
        days.setDays();
        addDayButton.disableProperty().setValue(Boolean.FALSE);
        if(days.getDays().size() > 0){
            
           ArrayList<Day> daysArrayList = days.getDays();
        dayList.clear();
        dayList.addAll(daysArrayList);
        listViewDays.setItems(dayList); 
        }
        
    }   
    
    //Adds a day and saves it to the user's file
    public void addDay(ActionEvent event){
        Day day = new Day();
        dayList.add(day);
        listViewDays.setItems(dayList);
        PrintWriter writer = null;
        
        
        
        try{
            File file = new File(key + ".txt");
            writer = new PrintWriter(file);
            
            for(int i = 0; i < dayList.size(); i++){
                writer.println(dayList.get(i).getPrintableObject());
            }
            
        }catch(FileNotFoundException exception){
            System.out.println("Something went wrong");
        }finally{
            writer.close();
            Days days = new Days(key);
            days.setDays();
            ArrayList<Day> daysArrayList = days.getDays();
            dayList.clear();
            dayList.addAll(daysArrayList);
        }
    }
    public void editDay(ActionEvent event)throws IOException{
            Day t = (Day) listViewDays.getSelectionModel().getSelectedItem();
            selectedDay = t;
            root = FXMLLoader.load(getClass().getResource("editDay.fxml"));
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();

    }

    public void logOut(ActionEvent event)throws IOException{
        root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public static int getKey(){
        try(Scanner fileInput = new Scanner(new File("keyFile.txt"))){
            String line;
            String[] tokens;
            int num;
            while(fileInput.hasNext()){
                line = fileInput.nextLine();
                tokens = line.split(",");               
                num = Integer.parseInt(tokens[0]);
                return num;
                
                
            }
            
            
            }catch(FileNotFoundException exception){
                System.out.println("There was an unexpected error");
                    
           }
                return -1;
    }
    
    
    @FXML
    private void buttonUpdateAction(ActionEvent actionEvent) throws IOException{
        // Get the Student object the user selected from the ListView.
        // Get the updated data from the controls.
        int caloriesInt;
        int proteinInt;
        boolean radioSelection1 = yes.isSelected();
        boolean radioSelection2 = no.isSelected();
        if(radioSelection1){
            selectedDay.setWentToGym(1);
        }else{
            selectedDay.setWentToGym(0);
        }
        try{
            caloriesInt = Integer.parseInt(textFieldCalories.getText());
            proteinInt = Integer.parseInt(textFieldProtein.getText());
        }catch(Exception e){
            caloriesInt = 0;
            proteinInt = 0;
        }
        
          
        
        selectedDay.setProtein(proteinInt);
        selectedDay.setCalories(caloriesInt);
        PrintWriter writer = null;
        try{
            File file = new File(key + ".txt");
            writer = new PrintWriter(file);
            
            for(int i = 0; i < dayList.size(); i++){
                writer.println(dayList.get(i).getPrintableObject());
            }
            
        }catch(FileNotFoundException exception){
            System.out.println("Something went wrong");
        }finally{
            writer.close();
            Days days = new Days(key);
            days.setDays();
            ArrayList<Day> daysArrayList = days.getDays();
            dayList.clear();
            dayList.addAll(daysArrayList);
        }

        
        root = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));
        stage = (Stage)((Node)actionEvent.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
       
        

        
        
    }   
    
    @FXML
    private void deleteDay(ActionEvent actionEvent){
        dayList.remove(selectedDay);
        
        PrintWriter writer = null;
        try{
            File file = new File(key + ".txt");
            writer = new PrintWriter(file);
            
            for(int i = 0; i < dayList.size(); i++){
                writer.println(dayList.get(i).getPrintableObject());
            }
            
        }catch(FileNotFoundException exception){
            System.out.println("Something went wrong");
        }finally{
            writer.close();
            Days days = new Days(key);
            days.setDays();
            ArrayList<Day> daysArrayList = days.getDays();
            dayList.clear();
            dayList.addAll(daysArrayList);
        }
        
    }
    public void editAccount(ActionEvent event) throws IOException{
        root = FXMLLoader.load(getClass().getResource("Login_1_1.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


            
    }    
    
    public void updateAccountButton(ActionEvent event) throws IOException{
        try{
            
            users.setUsers();
            
            ArrayList<User> usersArrayList = users.getUsers();
            getStatsExisting(usersArrayList.get(key));
            users.updateUsersFile();
            root = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }catch(Exception e){
            System.out.println("Input Mismatch");
        }
    }   
    
    public void getStatsExisting(User user) {
        
        
        String password = newPassword.getText();
        String age1 = age.getText();
        String heightFeet = height1.getText();
        String heightInches = height2.getText();
        String weight1 = weight.getText();
        String calorieGoal1 = calorieGoal.getText();
        String proteinGoal1 = proteinGoal.getText();
        user.setPassword(password);
        int heightIntFeet = Integer.parseInt(heightFeet);
        int heightIntInches = Integer.parseInt(heightInches);
        user.setAge(Integer.parseInt(age1));
        user.setHeight(heightIntFeet, heightIntInches);
        user.setWeight(Double.parseDouble(weight1) *  0.453592);
        if(calorieGoal1.equals("")){
            user.estimateCalories();
        }else{
            user.setCalorieGoal(Double.parseDouble(calorieGoal1));
        }
        
        user.setProteinGoal(Double.parseDouble(proteinGoal1));
        //users.setUsers();
        int index = users.getUsers().indexOf(user);
        key = index;
        user.setIndex(index);
        //users.updateUsersFile();
        
        

    }
    
    public static String callAdviceAPI(){
        URL url;
        InputStream inputStream;
        InputStreamReader inputStreamReader;
        BufferedReader reader = null;
        String jsonResult = "";
        
        try
        {
            // Create the URL with the address to the server.
            url = new URL("https://api.adviceslip.com/advice");
            
            // Call the url and create a Buffered Reader on the result.
            inputStream = url.openStream();
            inputStreamReader = new InputStreamReader(inputStream);
            reader = new BufferedReader(inputStreamReader);
            String line = reader.readLine();
                
            // Keep reading lines while more still exist.
            // Append the result to a String.  Should use a StringBuilder if we
            // are expecting a lot of lines.
            while (line != null) {
                jsonResult += line;
                line = reader.readLine();
            }
        }
        catch (MalformedURLException malformedURLException) {
            // URL was bad.
            jsonResult = malformedURLException.getMessage();
        }
        catch (IOException ioException) {
            // An error occurred during the reading process.
            jsonResult = ioException.getMessage();
        }
        finally
        {
            // Close the reader and the underlying objects.
            try
            {
                if (reader != null)
                {
                    reader.close();
                }
            }
            catch (IOException ioException) {
                jsonResult += ioException.getMessage();
            }
        }
        return jsonResult;
    }
    // Called when the program first starts.
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        
//        String json = callAdviceAPI();
//        Gson gson = new Gson();
//        json = json.substring(9, json.length() - 1);
//        
//        if(json.startsWith("{"))
//        {
//            // JSON is valid
//            Slip advice = gson.fromJson(json, new TypeToken<Slip>(){}.getType());
//            adviceText.setText("Your advice for the day: " + advice.getAdvice());
//
//        }
//        else
//        {
//            // String probably contains an error message from the server.
//            // Display it to the user.
//            adviceText.setText(json);
//        }
        
        
        
         key = getKey();   
         
         if(listViewDays != null){
             listViewDays.getSelectionModel().selectedItemProperty().addListener(
            dayChangeListener = (observable, oldValue, newValue) -> {
                
                // Set the selected Account.
                selectedDay = newValue;
                int dayB = dayList.indexOf(selectedDay) + 1;
                selectedDayLabel.setText("Selected Day: " + dayB);
                
            }
        );
         }
         if(listViewDays != null){
         editDayButton.disableProperty().bind(
            selectedDayLabel.textProperty().isEmpty()
                    );
         deleteDayButton.disableProperty().bind(
            selectedDayLabel.textProperty().isEmpty()
                    );
         addDayButton.disableProperty().setValue(Boolean.TRUE);
         
         }
    } 
}
