package cis2087finalproject;

public class Male extends User{
    
    private String gender;
    
    public Male(){
        gender = "m";
    }
    
    
    
    
    @Override
    public double estimateCalories(){
        double calories = 88.362 + (13.397 * this.getWeight()) + (4.799 * this.getHeight()) - (5.677 * this.getAge());
        return Math.round(calories * 1.27);
    }
    
    @Override
    public String getPrintableObject(){
        String text = this.getPassword() + "," + this.getCalorieGoal() + "," + Math.round(this.getHeight()) + "," + Math.round(this.getWeight()) + "," + this.getAge() + "," + this.getProteinGoal() +"," + gender + "," + this.getIndex();
        return text;
    }
    
    @Override
    public String toString(){
        String text = String.valueOf(this.getPassword());
        return text;
    }
    
    
}

