package cis2087finalproject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class FXMLDocumentController implements Initializable
{
    private static Users users = new Users();
    
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    private int index;
    // Controls from FXML GUI Interface.
    //Variables for login screen
    @FXML
    private Button button;
    @FXML
    private Label wrongLogIn;
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    
    //Variables for menu screen
    @FXML
    private ListView listViewDays;
    private ObservableList<Day> dayList = FXCollections.observableArrayList(Day.extractor);
    private ChangeListener<Day> dayChangeListener;
    private Day selectedDay;
    @FXML
    private Button viewLogsButton;
    
    //Variables for user
    
    private User user;
    @FXML
    private TextField newPassword;
    @FXML
    private TextField age;
    @FXML
    private TextField height1;
    @FXML
    private TextField height2;
    @FXML
    private TextField weight;
    @FXML
    private TextField calorieGoal;
    @FXML
    private TextField proteinGoal;
    @FXML
    private RadioButton male;
    @FXML
    private RadioButton female;
    @FXML
    private Label errorLabel;
    public static int key;
    
    
    
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        
    }
    
    //Check Logs button behavior
    public void checkLogs(ActionEvent event){
        Days days = new Days(key);
        days.setDays();
        ArrayList<Day> daysArrayList = days.getDays();
        dayList.clear();
        dayList.addAll(daysArrayList);
        listViewDays.setItems(dayList);
    }   
    
    //Adds a day and saves it to the user's file
    public void addDay(ActionEvent event){
        Day day = new Day();
        dayList.add(day);
        listViewDays.setItems(dayList);
        PrintWriter writer = null;
        
        try{
            File file = new File(key + ".txt");
            writer = new PrintWriter(file);
            
            for(int i = 0; i < dayList.size(); i++){
                writer.println(dayList.get(i).getPrintableObject());
            }
            
        }catch(FileNotFoundException exception){
            System.out.println("Something went wrong");
        }finally{
            writer.close();
        }
    }
    public void editDay(ActionEvent event){
        
    }
    //If password matches, open menu
    public void checkLogin(ActionEvent event) throws IOException{
        
        users.setUsers();
        

        String passwordAttempt = password.getText();
        
        boolean correct = existingUser(passwordAttempt);
        
        if(correct == true){
            
            root = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();           
        
        }else{
            wrongLogIn.setText("Incorrect Password. Try again.");
            
        }
        
            
        
            

        
    }
    //Checks if password matches
    public static boolean existingUser(String password){ 
        String thisPassword;
        for(int i = 0; i < users.getUsers().size(); i++){
            thisPassword = users.getUsers().get(i).getPassword();
            if(password.equals(thisPassword)){
                int index = users.getUsers().get(i).getIndex();
                key = index;
                updateKey();
                System.out.println("Retrieving account");
                
                
                
                return true;
            }else if(i + 1 == users.getUsers().size()){
                System.out.println("No account found with that password");
                
                return false;
            }
            
        }
        return false;   
        
    }
    //Opens new user screen
    public void newUser(ActionEvent event) throws IOException{
            root = FXMLLoader.load(getClass().getResource("Login_1.fxml"));
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            
            
    }
    //Create Account Button Behavior
    public void createAccount(ActionEvent event) throws IOException{
        try{
        boolean radioSelection1 = male.isSelected();
        boolean radioSelection2 = female.isSelected();
        if(radioSelection2){
            Female user = new Female();
            getStats(user);
            updateKey();
        }else{
            Male user = new Male();
            getStats(user);
            updateKey();
        }
            root = FXMLLoader.load(getClass().getResource("MainMenu.fxml"));
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }catch(Exception e){
            root = FXMLLoader.load(getClass().getResource("Login_1.fxml"));
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
            errorLabel.setText("There was an issue when creating your account. Please try again.");
            System.out.println("error");
        }
    }
    //Setting the stats that user input for new account
    public void getStats(User user) {
        String password = newPassword.getText();
        String age1 = age.getText();
        String heightFeet = height1.getText();
        String heightInches = height2.getText();
        String weight1 = weight.getText();
        String calorieGoal1 = calorieGoal.getText();
        String proteinGoal1 = proteinGoal.getText();
        user.setPassword(password);
        int heightIntFeet = Integer.parseInt(heightFeet);
        int heightIntInches = Integer.parseInt(heightInches);
        user.setAge(Integer.parseInt(age1));
        user.setHeight(heightIntFeet, heightIntInches);
        user.setWeight(Double.parseDouble(weight1) *  0.453592);
        if(calorieGoal1.equals("")){
            user.estimateCalories();
        }else{
            user.setCalorieGoal(Double.parseDouble(calorieGoal1));
        }
        user.setProteinGoal(Double.parseDouble(proteinGoal1));
        users.setUsers();
        users.addUser(user);
        int index = users.getUsers().indexOf(user);
        key = index;
        user.setIndex(index);
        users.updateUsersFile();
        user.makeFile();
        

    }
    
    public static void updateKey(){
        PrintWriter writer = null;
        
        try{
            File file = new File("keyFile.txt");
            writer = new PrintWriter(file);
            
          
                writer.println(key);
            
            
        }catch(FileNotFoundException exception){
            System.out.println("Something went wrong");
        }finally{
            writer.close();
        }
    }
    // Called when the program first starts.
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
            
    } 
}
