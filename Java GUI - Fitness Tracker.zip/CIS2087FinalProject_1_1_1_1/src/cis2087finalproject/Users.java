package cis2087finalproject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;


/**
 * Class for representing and controlling the list of users
 * 
 * @author tr79w
 */
public class Users {
    
    private ArrayList<User> users;
    private String FILE_NAME;
    
    /**
     * Default constructor - sets the name of the file to users.txt and creates a blank arraylist of users.
     */
    public Users(){
        FILE_NAME = "users.txt";
        users = new ArrayList<>();
    }
    
    /**
     * Set the users arraylist variable equal to the users contained in the users.txt file.
     * 
     */
    public void setUsers(){
        
        
        try(Scanner fileInput = new Scanner(new File(FILE_NAME))){
            users.clear();
            String line;
            String[] tokens;
            String password;
            double calorieGoal;
            double proteinGoal;
            double height;
            double weight;
            int age;
            int index;
            
            while(fileInput.hasNext()){
                line = fileInput.nextLine();
                tokens = line.split(",");
                password = tokens[0];
                calorieGoal = Double.parseDouble(tokens[1]);
                height = Double.parseDouble(tokens[2]);
                weight = Double.parseDouble(tokens[3]);
                age = Integer.parseInt(tokens[4]);
                proteinGoal = Double.parseDouble(tokens[5]);
                index = Integer.parseInt(tokens[7]);
                      
                if(tokens[6].equals("m")){
                    Male user = new Male();
                    user.setPassword(password);
                    user.setCalorieGoal(calorieGoal);
                    user.putHeight(height);
                    user.setWeight(weight);
                    user.setAge(age);
                    user.setProteinGoal(proteinGoal); 
                    users.add(user);
                    user.setIndex(users.indexOf(user));
                    
                    
                }else if(tokens[6].equals("f")){
                    Female user = new Female();
                    user.setPassword(password);
                    user.setCalorieGoal(calorieGoal);
                    user.putHeight(height);
                    user.setWeight(weight);
                    user.setAge(age);
                    user.setProteinGoal(proteinGoal);
                    user.setIndex(index);
                    users.add(user);
                    user.setIndex(users.indexOf(user));
                }
            }
            
        }catch(FileNotFoundException exception){
            System.out.println("There was an unexpected error");
        }
    }
    /**
     * Writes the contents of the users arraylist to the users.txt file.
     */
    public void updateUsersFile(){
        PrintWriter writer = null;
        
        try{
            File file = new File(FILE_NAME);
            writer = new PrintWriter(file);
            
            for(int i = 0; i < users.size(); i++){
                writer.println(users.get(i).getPrintableObject());
            }
            
        }catch(FileNotFoundException exception){
            System.out.println("Something went wrong");
        }finally{
            writer.close();
        }
    }
    
    /**
     * Add a user to the users arraylist
     * @param user user object to add to the arraylist
     */
    public void addUser(User user){
        users.add(user);
    }
    
    /**
     * Gets the users arraylist
     * @return users - arraylist of user objects
     */
    public ArrayList<User> getUsers(){
        return users;
    }
    
    /**
     * Removes all users from the users arraylist
     */
    public void clearUsers(){
        users.clear();
    }
    
    
    
}
