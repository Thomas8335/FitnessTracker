
package cis2087finalproject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleListProperty;


public class Days {
    
    private ArrayList<Day> days;
    private String FILE_NAME;
    
    
    public Days(int key){
        FILE_NAME = key + ".txt";
        days = new ArrayList();
    }
    
    //Read days from file
    public void setDays(){
        try(Scanner fileInput = new Scanner(new File(FILE_NAME))){
            String line;
            String[] tokens;
            int dayNumber;
            int protein;
            int wentToGym;
            int calories;
            days.clear();
            while(fileInput.hasNext()){
                line = fileInput.nextLine();
                tokens = line.split(",");               
                protein = Integer.parseInt(tokens[2]);
                wentToGym = Integer.parseInt(tokens[3]);
                calories = Integer.parseInt(tokens[4]);
                
                Day day = new Day();
                day.setProtein(protein);
                day.setWentToGym(wentToGym);
                day.setCalories(calories);
                days.add(day);
                dayNumber = days.indexOf(day) + 1;
                day.setDay(dayNumber);
                
            }
            
            
            }catch(FileNotFoundException exception){
                System.out.println("There was an unexpected error");
                    
           }
    }
    //Write to days file
    
    public ArrayList<Day> getDays(){
        return days;
    }
    
    public void addDay(Day day){
        days.add(day);
    }
    
     public void updateDaysFile(){
        PrintWriter writer = null;
        
        try{
            File file = new File(FILE_NAME);
            writer = new PrintWriter(file);
            
            for(int i = 0; i < days.size(); i++){
                writer.println(days.get(i).getPrintableObject());
            }
            
        }catch(FileNotFoundException exception){
            System.out.println("Something went wrong");
        }finally{
            writer.close();
        }
    }
}
