
package cis2087finalproject;

public class Female extends User{
    
    private String gender;
    
    public Female(){
        gender = "f";
    }
    
    
    
    @Override
    public double estimateCalories(){
        double calories = 447.593 + (9.274 * this.getWeight()) + (3.089 * this.getHeight()) - (4.330 * this.getAge());
        return Math.round(calories * 1.27);
    }
    
    @Override
    public String getPrintableObject(){
        String text = this.getPassword() + "," + this.getCalorieGoal() + "," + + Math.round(this.getHeight()) + "," + this.getWeight() + "," + this.getAge() + "," + String.valueOf(this.getProteinGoal()) + "," + gender + "," + this.getIndex();
        return text;
    }
    
    @Override
    public String toString(){
        String text = String.valueOf(this.getPassword());
        return text;
    }
    
    
}