
package cis2087finalproject;

public class Slip {
  
    public String advice;
    public int id;
    public Slip()
    {
        advice = "";
        id = 0;

    }
    
    public String getAdvice()
    {
        return advice;
    }
    
    public int getSlip()
    {
        return id;
    }
    
}
