
package cis2087finalproject;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;



public class User {
    private double heightCM;
    private double weightKG;
    private double bmi;
    private double proteinGoal;
    private double calorieGoal;
    private int age;
    private String password;
    private int index;
    //private File file;
    
    public User(){
        heightCM = 0;
        weightKG = 0;
        bmi = 0;
        proteinGoal = 0;
        calorieGoal = 0;
        age = 0;
        password = "";
        
    }

    public double getHeight() {
        return heightCM;
    }
    
    public void putHeight(double heightCM){
        this.heightCM = heightCM;
    }

    public void setHeight(int height, int height2) {
        this.heightCM = (height * 30.48) + (height2 * 2.54);
    }

    public double getWeight() {
        return weightKG;
    }

    public void setWeight(double weight) {
        this.weightKG = weight;
    }

    public double getBmi() {
        
        return bmi;
    }

    public void setBmi(double height, double weight) {
        this.bmi = weightKG / (Math.pow((heightCM / 100), 2));
    }

    public double getProteinGoal() {
        return proteinGoal;
    }

    public void setProteinGoal(double proteinGoal) {
        this.proteinGoal = proteinGoal;
    }

    public double getCalorieGoal() {
        return calorieGoal;
    }

    public void setCalorieGoal(double calorieGoal) {
        this.calorieGoal = calorieGoal;
    }
    
    public int getAge(){
        return age;
    }
    
    public void setAge(int age){
        this.age = age;
    }
    
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    

    public int getIndex(){
        return index;
    }
    
    public void setIndex(int inIndex){
        this.index = inIndex;
    }
    
    public double estimateCalories(){
        return 0;
    }
    
    public String getPrintableObject(){
        String text = this.getPassword() + this.getCalorieGoal();
        return text;
    }
    
    public void makeFile(){
        PrintWriter writer = null;
        
        
        try{
            File file = new File(index + ".txt");
            writer = new PrintWriter(file);
            //writer.println("");
            
        }catch(FileNotFoundException exception){
            
        }finally{
            writer.close();
        }
        
    }
    
    
}
