
package cis2087finalproject;
import java.util.List;
import javafx.beans.Observable;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ListProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleListProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.util.Callback;


public class Day {
    
    private IntegerProperty dayNumber;
    private IntegerProperty protein;
    private IntegerProperty wentToGym;
    private StringProperty date;
    private IntegerProperty calories;
    public Day(){
        dayNumber = new SimpleIntegerProperty(this, "dayNumber", 0);
        protein = new SimpleIntegerProperty(this, "protein", 0);
        wentToGym = new SimpleIntegerProperty(this, "wentToGym", 0);
        calories = new SimpleIntegerProperty(this, "calories", 0);
        date = new SimpleStringProperty(this, "date", java.time.LocalDate.now().toString());
        
    }
    
    public void setDay(int inDay){
        dayNumber.set(inDay);
    }
    
    public IntegerProperty dayProperty(){
        return dayNumber;
    }
    
    public int getDay(){
        return dayNumber.get();
    }
    
    public void setProtein(int inProtein){
        protein.set(inProtein);
    }
    
    public IntegerProperty proteinProperty(){
        return protein;
    }
    
    public int getProtein(){
        return protein.get();
    }
    
    public void setCalories(int inCalories){
        calories.set(inCalories);
    }
    
    public IntegerProperty caloriesProperty(){
        return calories;
    }
    
    public int getCalories(){
        return calories.get();
    }
    
    public void setWentToGym(int inGym){
        wentToGym.set(inGym);
    }
    
    public StringProperty wentToGymProperty(){
        if(wentToGym.toString().equals("1")){
            return new SimpleStringProperty(this,"Went to the gym");
        }else{
            return new SimpleStringProperty(this,"Rest from gym");
        }
    }
    
    public int getWentToGym(){
        return wentToGym.get();
    }
    
    
    
    public String getPrintableObject(){
        String text = date.getValue() + "," + dayNumber.getValue() + "," + protein.getValue()+ "," + wentToGym.getValue() + "," + calories.getValue();
        return text;
    }
    
    @Override
    public String toString(){
        String text = "Date: " + date.getValue() + ", " +  calories.getValue() + " calories, " + protein.getValue() + " grams of protein, " + wentToGym.get();
        return text;
    }
    
        @Override
    public boolean equals(Object object)
    {
        boolean areEqual;
        
        if (this == object)
        {
            areEqual = true;
        }
        else if (object == null)
        {
            areEqual = false;
        }
        else if (getClass() != object.getClass())
        {
            areEqual = false;
        }
        else
        {
            Day other = (Day) object;
            
            if (getDay()==(other.getDay())
                    && getProtein()==(other.getProtein()))
            {
                areEqual = true;
            }
            else
            {
                areEqual = false;
            }
        }

        return areEqual;
    }
    
    public static Callback<Day, Observable[]> extractor = p -> new Observable[]
        {p.proteinProperty(), p.caloriesProperty(), p.dayProperty(), p.wentToGymProperty()};
    
    
}